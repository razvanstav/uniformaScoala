# MEAI — Uniforme școlare, versiunea statică 1

Deschide `index.html` direct în browser. Toate fișierele necesare sunt locale; pagina nu cere instalare, build sau conexiune la un serviciu extern. Pentru previzualizarea din workspace se poate folosi `node qa/serve.cjs`, executat din directorul părinte, apoi http://127.0.0.1:4173/.

## Structură

```text
uniforme-scolare-landing/
  index.html
  css/styles.css
  js/main.js
  assets/
    product-01.jpg … product-06.jpg
    hero.jpg
    logo.svg
    image-prompts.md
    fonts/
      archivo-expanded-latin.woff2
      archivo-expanded-latin-ext.woff2
      OFL.txt
```

## Referința vizuală

Analiză vizuală și măsurători ale paginii [Milano / Shirts](https://milano-template.modulify.website/category/shirts), 5 septembrie 2026. Nu s-au copiat HTML, CSS, JavaScript sau imagini de pe Milano.

- Intro centrat, mult spațiu deasupra, font Archivo Expanded, navigație discretă.
- La 1440 px, referința are un heading de 64 px, margini laterale de aproximativ 66 px, spații de 30 px între produse și fotografii de aproximativ 301 × 360 px. Cele trei produse ocupă trei poziții dintr-un grid de patru coloane.
- La 390 px, referința folosește un produs pe rând, margini de 14 px și un heading de 28 px. Footer-ul original este închis la culoare, cu o bandă decorativă și newsletter.
- Adaptările cerute pentru MEAI: fundal off-white mai deschis, titlu mai mare, trei coloane complete pe desktop, două pe tabletă, una pe telefon, selector de școli și bara de categorii. Footer-ul alb, bannerul și CTA-ul pentru parteneri păstrează ierarhia editorială, cu conținutul din brief. Newsletter-ul, banda animată și funcțiile de cumpărare din referință nu au fost reproduse.

## Modificări ulterioare

- **Școli:** editează exclusiv `const schools` din `js/main.js`. Dropdown-ul este generat integral din acest array. Selectarea navighează la `school.url`.
- **Căutare opțională în școli:** schimbă `selectorSettings.searchEnabled` din `false` în `true`. Acceptă căutarea fără diacritice. Implicit, câmpul nu este afișat.
- **Categorii, produse și cont:** înlocuiește `href="#"` direct în HTML. Linkurile devin active fără alte schimbări; handlerul ignoră doar placeholder-ele cu valoarea exactă `#`.
- **Fotografii:** înlocuiește JPEG-urile păstrând denumirile. Produsele au 900 × 1125 px (4:5), iar bannerul 1600 × 1000 px. Actualizează atributele `width`, `height` și `alt` dacă se schimbă imaginile.
- **Aspect:** culorile și marginile de bază sunt variabile `--school-*` pe wrapper. Pragurile principale sunt 600 px și 1024 px; ajustarea secundară desktop este la 1280 px.

## Materiale demonstrative

Cele șapte fotografii sunt generate cu instrumentul integrat ImageGen, exclusiv pentru această previzualizare. Nu reprezintă inventarul real MEAI. Prompturile exacte și corespondența imaginilor sunt în `assets/image-prompts.md`. Prețurile sunt exemplele din brief. `logo.svg` este un wordmark MEAI provizoriu desenat vectorial, care poate fi înlocuit cu logo-ul oficial.

Archivo este găzduit local, cu caracterele românești incluse. Sursă: [Google Fonts / Archivo](https://fonts.google.com/specimen/Archivo). Licența SIL Open Font License este inclusă în `assets/fonts/OFL.txt`.

## Interacțiuni și accesibilitate

- Enter / Space deschid selectorul și activează școala focalizată.
- Săgețile sus / jos parcurg lista; Home / End sar la început / sfârșit. Tastarea caută după începutul numelui.
- Escape închide selectorul și restabilește focusul. Tab iese natural din listă, fără blocarea tastaturii. Clickul exterior închide lista.
- Lista are scroll propriu, iar înălțimea se adaptează la spațiul vizibil.
- Meniul mobil se deschide din buton, se închide cu Escape, la click exterior sau la ieșirea focusului.
- CTA-ul editorial derulează la selector și îi mută focusul. Mișcarea redusă dezactivează tranzițiile și derularea lină.
- Un singur H1, limbă română, landmarks semantice, focus vizibil și link „Sari la conținut”.

## Limita acestei etape

Doar HTML5, Vanilla CSS și Vanilla JavaScript. Fără pachete, framework-uri, PHP, baze de date, API-uri, autentificare sau coș funcțional. Categoriile nu filtrează produsele.

Pentru integrarea viitoare, wrapper-ul `#school-uniforms-landing` și referințele către CSS/JS vor fi introduse în template-ul dedicat. Toți selectorii paginii sunt izolați în wrapper, clasele sunt prefixate `school-`, iar familia fontului are un nume propriu. Nu există `!important`. Marginea inline a elementului `body` aparține doar documentului standalone și nu trebuie transferată în OpenCart. Dezactivarea Journal și verificarea în tema reală rămân pentru etapa următoare.

Validarea și capturile de browser sunt în directorul `../qa/`. Fișierele paginii, inclusiv fotografiile și fonturile, însumează aproximativ 1 MB; nu există cereri de rețea externe pentru randare. Deschiderea linkurilor către MEAI necesită internet.
