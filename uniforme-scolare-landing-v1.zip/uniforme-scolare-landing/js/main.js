(() => {
  'use strict';

  const landing = document.getElementById('school-uniforms-landing');
  if (!landing) return;

  // Single source of truth. Add, remove or reorder schools only here.
  const schools = [
    {
      name: 'Liceul Teoretic "Mihai Ionescu"',
      url: 'https://meai.ro/uniforme-scolare/liceul-teoretic-mihai-ionescu'
    },
    {
      name: 'Școala Gimnazială "M. Sântimbreanu"',
      url: 'https://meai.ro/uniforme-scolare/scoala-gimnaziala-m-santimbreanu'
    },
    {
      name: 'Școala Gimnazială Nr. 2 "Mihai Viteazul"',
      url: 'https://meai.ro/uniforme-scolare/scoala-gimnaziala-nr-2-mihai-viteazul'
    },
    {
      name: 'Școala Gimnazială "Mihai Eminescu"',
      url: 'https://meai.ro/uniforme-scolare/scoala-gimnaziala-mihai-eminescu'
    },
    {
      name: 'Școala Gimnazială Nr. 7',
      url: 'https://meai.ro/uniforme-scolare/scoala-gimnaziala-nr-7'
    },
    {
      name: 'Liceul Teologic Adventist "Ștefan Demetrescu"',
      url: 'https://meai.ro/uniforme-scolare/liceul-teologic-adventist-stefan-demetrescu'
    },
    {
      name: 'Școala Gimnazială "Avram Iancu"',
      url: 'https://meai.ro/uniforme-scolare/scoala-gimnaziala-avram-iancu'
    },
    {
      name: 'Școala Gimnazială "Ștefan cel Mare"',
      url: 'https://meai.ro/uniforme-scolare/scoala-gimnaziala-stefan-cel-mare'
    },
    {
      name: 'Colegiul Național "AI Cuza" Alexandria',
      url: 'https://meai.ro/uniforme-scolare/colegiul-national-ai-cuza-alexandria'
    }
  ];

  // Set to true to show the optional local school search. No network calls.
  const selectorSettings = { searchEnabled: false };
  const selector = landing.querySelector('.school-school-selector');
  const trigger = landing.querySelector('#school-selector-trigger');
  const panel = landing.querySelector('#school-selector-panel');
  const list = landing.querySelector('#school-listbox');
  const search = landing.querySelector('#school-search-input');
  const searchWrapper = landing.querySelector('#school-selector-search');
  const emptyMessage = landing.querySelector('#school-selector-empty');
  let options = [];
  let typed = '';
  let typeTimer;

  const normalize = (value) => value.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLocaleLowerCase('ro');
  const visibleOptions = () => options.filter((option) => !option.hidden);

  function focusOption(option) {
    if (!option) return;
    options.forEach((item) => { item.tabIndex = item === option ? 0 : -1; });
    option.focus({ preventScroll: true });
    // Scroll only the list, not the entire page below the trigger.
    const top = option.offsetTop - list.offsetTop;
    if (top < list.scrollTop) list.scrollTop = top;
    if (top + option.offsetHeight > list.scrollTop + list.clientHeight) {
      list.scrollTop = top + option.offsetHeight - list.clientHeight;
    }
  }

  function resetSearch() {
    search.value = '';
    options.forEach((option) => { option.hidden = false; });
    emptyMessage.hidden = true;
  }

  function fitSchoolList() {
    if (panel.hidden) return;
    const viewHeight = window.visualViewport ? window.visualViewport.height : window.innerHeight;
    let available = viewHeight - trigger.getBoundingClientRect().bottom;
    if (available < 220) {
      selector.scrollIntoView({ behavior: 'instant', block: 'start' });
      available = viewHeight - trigger.getBoundingClientRect().bottom;
    }
    const searchHeight = selectorSettings.searchEnabled ? searchWrapper.offsetHeight : 0;
    list.style.maxHeight = `${Math.max(120, Math.min(360, available - searchHeight - 28))}px`;
  }

  function openSelector(last = false) {
    closeMenu();
    resetSearch();
    panel.hidden = false;
    trigger.setAttribute('aria-expanded', 'true');
    fitSchoolList();
    if (selectorSettings.searchEnabled && !last) search.focus({ preventScroll: true });
    else focusOption(last ? options[options.length - 1] : options[0]);
  }

  function closeSelector(returnFocus = false) {
    panel.hidden = true;
    trigger.setAttribute('aria-expanded', 'false');
    typed = '';
    window.clearTimeout(typeTimer);
    if (returnFocus) trigger.focus({ preventScroll: true });
  }

  const fragment = document.createDocumentFragment();
  schools.forEach((school, index) => {
    const option = document.createElement('button');
    const name = document.createElement('span');
    const arrow = document.createElement('span');
    option.type = 'button';
    option.className = 'school-selector-option';
    option.id = `school-option-${index}`;
    option.setAttribute('role', 'option');
    option.setAttribute('aria-selected', 'false');
    option.tabIndex = -1;
    name.textContent = school.name;
    arrow.textContent = '↗';
    arrow.setAttribute('aria-hidden', 'true');
    option.append(name, arrow);
    option.addEventListener('click', () => {
      option.setAttribute('aria-selected', 'true');
      window.location.href = school.url;
    });
    fragment.append(option);
    options.push(option);
  });
  list.append(fragment);
  searchWrapper.hidden = !selectorSettings.searchEnabled;
  trigger.disabled = false;

  trigger.addEventListener('click', () => {
    if (panel.hidden) openSelector();
    else closeSelector();
  });
  trigger.addEventListener('keydown', (event) => {
    if (event.key !== 'ArrowDown' && event.key !== 'ArrowUp') return;
    event.preventDefault();
    openSelector(event.key === 'ArrowUp');
  });

  panel.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') {
      event.preventDefault();
      closeSelector(true);
      return;
    }
    const visible = visibleOptions();
    const current = visible.indexOf(document.activeElement);
    if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
      event.preventDefault();
      const next = event.key === 'ArrowDown' ? current + 1 : (current < 0 ? visible.length - 1 : current - 1);
      focusOption(visible[(next + visible.length) % visible.length]);
    } else if (document.activeElement !== search && ['Home', 'End'].includes(event.key)) {
      event.preventDefault();
      focusOption(event.key === 'Home' ? visible[0] : visible[visible.length - 1]);
    } else if (document.activeElement !== search && event.key.length === 1 && event.key !== ' ' && !event.ctrlKey && !event.metaKey && !event.altKey) {
      // Type-ahead is available even while the optional search field is hidden.
      typed += normalize(event.key);
      window.clearTimeout(typeTimer);
      typeTimer = window.setTimeout(() => { typed = ''; }, 700);
      const matched = visible.find((option) => normalize(option.firstElementChild.textContent).startsWith(typed));
      focusOption(matched);
    }
    // Enter / Space use the button's native activation. Tab is never trapped.
  });

  search.addEventListener('input', () => {
    const query = normalize(search.value.trim());
    options.forEach((option) => { option.hidden = !normalize(option.firstElementChild.textContent).includes(query); });
    emptyMessage.hidden = visibleOptions().length > 0;
  });
  selector.addEventListener('focusout', () => {
    queueMicrotask(() => {
      if (!selector.contains(document.activeElement)) closeSelector();
    });
  });
  window.addEventListener('resize', fitSchoolList);
  if (window.visualViewport) window.visualViewport.addEventListener('resize', fitSchoolList);

  // The same navigation becomes a compact disclosure on smaller viewports.
  const menuButton = landing.querySelector('.school-menu-toggle');
  const menu = landing.querySelector('#school-menu');
  const header = landing.querySelector('.school-header');
  const desktop = window.matchMedia('(min-width: 1024px)');

  function closeMenu(returnFocus = false) {
    menu.hidden = !desktop.matches;
    menuButton.setAttribute('aria-expanded', 'false');
    menuButton.setAttribute('aria-label', 'Deschide meniul');
    if (returnFocus) menuButton.focus();
  }
  function syncMenu() {
    const focusedInMenu = menu.contains(document.activeElement);
    menuButton.hidden = desktop.matches;
    closeMenu(focusedInMenu && !desktop.matches);
  }
  menuButton.addEventListener('click', () => {
    const willOpen = menu.hidden;
    closeSelector();
    menu.hidden = !willOpen;
    menuButton.setAttribute('aria-expanded', String(willOpen));
    menuButton.setAttribute('aria-label', willOpen ? 'Închide meniul' : 'Deschide meniul');
    if (willOpen) menu.querySelector('a').focus();
  });
  menu.addEventListener('click', (event) => {
    if (event.target.closest('a')) closeMenu();
  });
  header.addEventListener('focusout', () => {
    queueMicrotask(() => {
      if (!header.contains(document.activeElement)) closeMenu();
    });
  });
  desktop.addEventListener('change', syncMenu);
  syncMenu();
  landing.classList.add('school-ready');

  document.addEventListener('pointerdown', (event) => {
    if (!selector.contains(event.target)) closeSelector();
    if (!header.contains(event.target)) closeMenu();
  });
  document.addEventListener('keydown', (event) => {
    if (event.key !== 'Escape') return;
    if (!panel.hidden) closeSelector(true);
    if (!desktop.matches && !menu.hidden) closeMenu(true);
  });

  landing.addEventListener('click', (event) => {
    const link = event.target.closest('a');
    if (!link) return;
    // Changing href to an actual URL is sufficient to activate a placeholder.
    if (link.hasAttribute('data-school-placeholder') && link.getAttribute('href') === '#') {
      event.preventDefault();
      return;
    }
    if (link.hasAttribute('data-school-selector-link')) {
      event.preventDefault();
      closeSelector();
      const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
      selector.scrollIntoView({ behavior: reducedMotion ? 'instant' : 'smooth', block: 'start' });
      trigger.focus({ preventScroll: true });
    }
  });
})();
